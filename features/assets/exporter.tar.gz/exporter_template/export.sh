#!/bin/sh

echo Module Contents >> $4
ls $1 >> $4
