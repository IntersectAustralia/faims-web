#!/bin/sh

echo Exporter Uninstall Failure!

exit 1