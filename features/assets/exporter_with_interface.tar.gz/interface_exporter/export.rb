require "json"
json = JSON.parse(File.read(ARGV[0]))
File.open(ARGV[1], 'w+') do |f|
  f.puts "## Output"
  f.puts "+ **Name** is #{json["Name"]}"
  f.puts "+ **Text** is #{json["Text"].join(" ")}"
  f.puts "+ **State** is #{json["State"]}"
end

