#!/bin/sh

ruby export.rb $2 $4

touch $3/test.txt
echo "This is a test download with some amazing content" >> $3/test.txt