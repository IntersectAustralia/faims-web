#!/bin/sh

echo Exporter Uninstalled